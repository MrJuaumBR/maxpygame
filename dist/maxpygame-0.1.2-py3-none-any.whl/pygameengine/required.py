"""
A File designed only to import things for all the project.
"""
import math, os, random, sys, time
import pygame as pg
from pygame.locals import *
import inspect
from .excptions import *