from setuptools import setup

Description_MD = """
# PyGameEngine
A simple pygame engine
*this engine is made in Python for work with pygame, come with some utilities that makes easier and faster to creates simple pygame projects*

All credits to PyGame Owners

[PyGame](https://www.pygame.org/)
"""

setup(
    long_description=Description_MD,
    long_description_content_type='text/markdown',
)